The following libraries are included in the JEval project distribution because they are
required for building the project and the sample apps. Note that each of these libraries is 
subject to their respective license; check the respective project distribution/website before 
using any of them in your own applications.

* ant/ant.jar
* ant/ant-junit.jar
* ant/ant-launcher.jar
- Ant 1.6.2 (http://ant.apache.org)
- used to build the project

* junit/junit.jar
- JUnit 3.8.1 (http://www.junit.org)
- used to build and run the tests


